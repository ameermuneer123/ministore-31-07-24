
package dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.*;
import java.util.stream.Collectors;
import bean.Product;


public class ProductDAO {
    private static final String URL = "jdbc:mysql://localhost:3306/ministore";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    private static final String DRIVER_CLASS = "com.mysql.jdbc.Driver";

    public ProductDAO() {
        try {
            Class.forName(DRIVER_CLASS);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        String query = "SELECT id, name, price, size, colour, storage, ram, highlight, description, specification, image_url FROM products";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt("id"));
                product.setName(rs.getString("name"));
                product.setPrice(rs.getInt("price"));
                product.setSize(rs.getString("size"));
                product.setColor(rs.getString("colour"));
                product.setStorage(rs.getString("storage"));
                product.setRam(rs.getString("ram"));
                product.setHighlight(rs.getString("highlight"));
                product.setDescription(rs.getString("description"));
                product.setSpecification(rs.getString("specification"));
                product.setImage_url(rs.getString("image_url"));
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }

    public Product getProductById(int id) {
        Product product = null;
        String query = "SELECT id, name, price, size, colour, storage, ram, highlight, description, specification, image_url FROM products WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement(query)) {
            
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                product = new Product();
                product.setId(rs.getInt("id"));
                product.setName(rs.getString("name"));
                product.setPrice(rs.getInt("price"));
                product.setSize(rs.getString("size"));
                product.setColor(rs.getString("colour"));
                product.setStorage(rs.getString("storage"));
                product.setRam(rs.getString("ram"));
                product.setHighlight(rs.getString("highlight"));
                product.setDescription(rs.getString("description"));
                product.setSpecification(rs.getString("specification"));
                product.setImage_url(rs.getString("image_url"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return product;
    }

    public boolean updateProduct(Product product) {
        String query = "UPDATE products SET name = ?, price = ?, size = ?, colour =?, storage = ?, ram = ?, highlight = ?, description = ?, specification = ?, image_url = ? WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, product.getName());
            stmt.setInt(2, product.getPrice());
            stmt.setString(3, product.getSize());
            stmt.setString(4, product.getColor());
            stmt.setString(5, product.getStorage());
            stmt.setString(6, product.getRam());
            stmt.setString(7, product.getHighlight());
            stmt.setString(8, product.getDescription());
            stmt.setString(9, product.getSpecification());
            stmt.setString(10, product.getImage_url());
            stmt.setInt(11, product.getId());
            
            int rowsUpdated = stmt.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public static Map<Integer, Product> getProductsByIds(Set<Integer> productIds) throws SQLException {
        Map<Integer, Product> products = new HashMap<>();
        if (productIds.isEmpty()) {
            return products;
        }

        String ids = productIds.stream().map(String::valueOf).collect(Collectors.joining(","));
        String query = "SELECT * FROM products WHERE id IN (" + ids + ")";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int price = rs.getInt("price");
                Product product = new Product(id, name, price);
                products.put(id, product);
            }
        }

        return products;
    }
}
